<?php
date_default_timezone_set("Asia/Kolkata");

error_reporting(E_ALL);
ini_set('display_errors', 1);
$servername = "localhost";
$username = "virtualw_api";
$password = "virtualw_api";
$dbname = "virtualw_api";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$name = 'default';
if(isset($_REQUEST['status'])){
	$name = $_REQUEST['status'];
}

$sql = "SELECT * from knob ORDER BY id DESC LIMIT 1 ";
$query = $conn->query($sql);
$row = $query->fetch_array();
$data['status'] = $row['status'];
echo "{KNOB STATUS ".strtoupper($row['status'])." OK}$";

/*if(headers_sent()){
    foreach(headers_list() as $header){
        header_remove($header);
    }
}*/
header_remove("Server");
header_remove("X-Powered-By");
header_remove("Upgrade");
header_remove("Vary");
header_remove("Content-Encoding");



$conn->close();
?>