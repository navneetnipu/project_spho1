CREATE TABLE `sensor` (
	id INT(8) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
	status VARCHAR(255) NOT NULL,
	date TIMESTAMP DEFAULT NOW()
)ENGINE = InnoDB CHARSET=utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE TABLE `alarm` (
	id INT(8) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
	status VARCHAR(255) NOT NULL,
	date TIMESTAMP DEFAULT NOW()
)ENGINE = InnoDB CHARSET=utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE TABLE `knob` (
	id INT(8) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
	status VARCHAR(255) NOT NULL,
	date TIMESTAMP DEFAULT NOW()
)ENGINE = InnoDB CHARSET=utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE TABLE `action` (
	id INT(8) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
	action_on VARCHAR(255) NOT NULL,
	action VARCHAR(255) NOT NULL,
    date TIMESTAMP DEFAULT NOW()
)ENGINE = InnoDB CHARSET=utf8mb4 COLLATE utf8mb4_unicode_ci;




GET SENSOR STATUS :: http://api.virtualword.today/sensor_read.php

SEND SENSOR DATA :: http://api.virtualword.today/sensor_write.php

GET ALARM STATUS :: http://api.virtualword.today/alarm_read.php

SEND ALARM DATA :: http://api.virtualword.today/alarm_write.php

GET KNOB STATUS :: http://api.virtualword.today/knob_read.php

SEND KNOB DATA :: http://api.virtualword.today/knob_write.php


SEND action data:: http://api.virtualword.today/action.php?on=knob&action=off
