<?php
date_default_timezone_set("Asia/Kolkata");
error_reporting(E_ALL);
ini_set('display_errors', 1);
$servername = "localhost";
$username = "virtualw_api";
$password = "virtualw_api";
$dbname = "virtualw_api";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$on = 'default';

if(isset($_REQUEST['on'])){
	$on = $_REQUEST['on'];


$sql = "SELECT * from action WHERE LOWER(`action_on`)=LOWER('".$on."')  ORDER BY id DESC LIMIT 1 ";
$query = $conn->query($sql);
$row = $query->fetch_array();

$data['status'] = $row['status'];
$data['action'] = $row['action'];

echo "{".strtoupper($on)." ".$row['status']." ".strtoupper($row['action'])."}$";
}

/*if(headers_sent()){
    foreach(headers_list() as $header){
        header_remove($header);
    }
}*/
header_remove("Server");
header_remove("X-Powered-By");
header_remove("Upgrade");
header_remove("Vary");
header_remove("Content-Encoding");



$conn->close();
?>