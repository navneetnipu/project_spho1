<?php
$servername = "localhost";
$username = "virtualw_test";
$password = "virtualw_test";
$dbname = "virtualw_test";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$name = 'default';
if(isset($_REQUEST['name'])){
	$name = $_REQUEST['name'];
}
if($name!='default' && $name!=null && $name!=''){
    $sql = "INSERT INTO test (name) VALUES ('$name')";
    
    if ($conn->query($sql) === TRUE) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
    
    $conn->close();
}
?>