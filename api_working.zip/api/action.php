<?php
date_default_timezone_set("Asia/Kolkata");
error_reporting(E_ALL);
ini_set('display_errors', 1);
$servername = "localhost";
$username = "virtualw_api";
$password = "virtualw_api";
$dbname = "virtualw_api";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$on = 'default';
$action = 'default';
if(isset($_REQUEST['on']) && isset($_REQUEST['action'])){
	$on = $_REQUEST['on'];
	$action = $_REQUEST['action'];
	
}
if($on!='default' && $on!=null && $on!='' && $action!='default' && $action!='' && $action!=null){
    $sql = "INSERT INTO action (`action_on`,`action`) VALUES ('$on','$action')";
    
    if ($conn->query($sql) === TRUE) {
        echo "##SUCCESS##New record created successfully##OKEND##";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
    
    $conn->close();
}
print_r($_REQUEST);
?>